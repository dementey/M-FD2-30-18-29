﻿import './style2.css';

const quadra = x => x*x;

export {quadra};
