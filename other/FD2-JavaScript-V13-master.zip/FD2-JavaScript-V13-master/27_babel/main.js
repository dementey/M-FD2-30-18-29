
const AAA=111;

let sum=(a,b) => a+b;

console.log( sum(AAA,222) );
