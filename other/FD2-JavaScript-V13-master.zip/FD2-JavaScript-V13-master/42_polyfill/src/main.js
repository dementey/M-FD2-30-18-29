import "babel-polyfill";

import './style1.css';

import {quadra} from './second.js'

document.getElementById('FOOTBALL').innerHTML+=" "+quadra(5);
